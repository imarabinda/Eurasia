/*
 Template Name: Dashor - Responsive Bootstrap 4 Admin Dashboard
 Author: Themesdesign
 Website: www.themesdesign.in
 File: Responsive Table
 */

$(function () {
  $('.table-responsive').responsiveTable({
    addDisplayAllBtn: 'btn btn-secondary'
  });
});